package com.example.register;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

public class MainActivity extends AppCompatActivity {

    Button button;
    Button signupwith;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = findViewById(R.id.btn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                startActivity(intent);
            }
        });

        signupwith = findViewById(R.id.signupwith);
        signupwith.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotUri("https://www.facebook.com/chhaydev");
            }
        });

        EditText username = (EditText) findViewById(R.id.username);

        MaterialButton regbtn = (MaterialButton) findViewById(R.id.signinbtn);
        regbtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                String username1 = username.getText().toString();
                Toast.makeText(MainActivity.this, "Username is " + username1, Toast.LENGTH_SHORT).show();

            }
        });
    }

    private void gotUri(String s) {

        Uri uri = Uri.parse(s);

        startActivity(new Intent(Intent.ACTION_VIEW,uri));
    }
}