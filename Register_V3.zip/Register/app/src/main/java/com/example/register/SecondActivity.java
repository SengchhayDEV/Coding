package com.example.register;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        EditText username = (EditText) findViewById(R.id.comfirmpassword);

        MaterialButton regbtn = (MaterialButton) findViewById(R.id.resetbtn);
        regbtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                String comfirmpassword = username.getText().toString();
                Toast.makeText(SecondActivity.this, " " + comfirmpassword, Toast.LENGTH_SHORT).show();

            }
        });
    }

}